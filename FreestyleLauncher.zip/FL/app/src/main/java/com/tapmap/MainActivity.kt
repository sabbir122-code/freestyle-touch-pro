package com.tapmap

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        fun tv(t: String, sz: Float = 14f) { root.addView(TextView(this).apply { text = t; textSize = sz; setPadding(0, 24, 0, 8) }) }
        fun btn(t: String, f: () -> Unit) { root.addView(Button(this).apply { text = t; setOnClickListener { f() } }) }
        tv("Freestyle Launcher", 24f)
        btn("Enable accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        tv("My Games (tap = open, long-press = remove)", 16f)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        btn("+ Add Games") { addGame() }
        tv("Macro (one command per line):\nclick X Y\nmulticlick X Y (repeats while key held)\nslide X1 Y1 X2 Y2 MS\nwait MS")
        val ed = EditText(this).apply { hint = "click 500 300\nwait 100\nslide 200 600 200 300 300"; minLines = 4 }
        root.addView(ed)
        btn("Bind macro to a key") {
            val s = MapService.inst
            if (s == null) Toast.makeText(this, "Enable the service first", Toast.LENGTH_SHORT).show() else s.macro(ed.text.toString())
        }
        tv("In game: tap the FL bubble to add Key, Multiply, Swipe or Order mappings.")
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun games(): Set<String> = getSharedPreferences("p", 0).getStringSet("games", emptySet())!!.toSet()
    private fun saveGames(s: Set<String>) { getSharedPreferences("p", 0).edit().putStringSet("games", HashSet(s)).apply() }

    private fun render() {
        list.removeAllViews()
        for (pkg in games()) {
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            list.addView(Button(this).apply {
                text = label
                setOnClickListener { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }
                setOnLongClickListener { saveGames(games() - pkg); render(); true }
            })
        }
    }

    private fun addGame() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this).setTitle("Add game")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i -> saveGames(games() + apps[i].first); render() }.show()
    }
}
