package com.tapmap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MapService : AccessibilityService() {
    companion object { var inst: MapService? = null }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val maps = HashMap<String, HashMap<Int, String>>()
    private val down = HashSet<Int>()
    private var cur: String? = null
    private var bubble: View? = null
    private var panel: View? = null
    private var cap: View? = null
    private var buf = ArrayList<String>()
    private var bindReady = false
    private var feedback = false

    override fun onServiceConnected() { inst = this; wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = e?.packageName?.toString() ?: return
        if (p == packageName) return
        val games = getSharedPreferences("p", 0).getStringSet("games", emptySet())!!
        val n = if (games.contains(p)) p else null
        if (n == cur) return
        cur = n
        if (n != null) { if (!maps.containsKey(n)) load(n); showBubble() } else hideAll()
    }

    // ---- key handling ----
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        val c = cur ?: return false
        if (bindReady) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                maps.getOrPut(c) { HashMap() }[k] = buf.joinToString(";")
                bindReady = false
                cap?.let { wm.removeView(it) }; cap = null
                save(); toast("Saved: " + KeyEvent.keyCodeToString(k))
            }
            return true
        }
        val s = maps[c]?.get(k) ?: return false
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount == 0) { down.add(k); exec(k, s.split(";"), 0) }
        } else if (e.action == KeyEvent.ACTION_UP) down.remove(k)
        return true
    }

    // ---- script runner: click / turbo / slide / wait ----
    private fun exec(k: Int, l: List<String>, i: Int) {
        if (i >= l.size) return
        fun next(ms: Long) { h.postDelayed({ exec(k, l, i + 1) }, ms) }
        try {
            val p = l[i].trim().split(" ")
            when (p[0]) {
                "click" -> { tap(p[1].toFloat(), p[2].toFloat()); next(60) }
                "turbo" -> if (k in down) { tap(p[1].toFloat(), p[2].toFloat()); h.postDelayed({ exec(k, l, i) }, 60) } else exec(k, l, i + 1)
                "slide" -> {
                    val ms = p[5].toLong()
                    val path = Path().apply { moveTo(p[1].toFloat(), p[2].toFloat()); lineTo(p[3].toFloat(), p[4].toFloat()) }
                    stroke(path, ms); next(ms + 20)
                }
                "wait" -> next(p[1].toLong())
                else -> exec(k, l, i + 1)
            }
        } catch (ex: Exception) { }
    }

    private fun stroke(path: Path, ms: Long) {
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build(), null, null)
    }
    private fun tap(x: Float, y: Float) { dot(x, y); stroke(Path().apply { moveTo(x, y) }, 40) }

    private fun dot(x: Float, y: Float) {
        if (!feedback) return
        val d = View(this).apply { setBackgroundColor(0xAAFF0000.toInt()) }
        val p = lp(40, 40, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE).apply { gravity = Gravity.TOP or Gravity.START; this.x = (x - 20).toInt(); this.y = (y - 20).toInt() }
        wm.addView(d, p)
        h.postDelayed({ try { wm.removeView(d) } catch (ex: Exception) { } }, 250)
    }

    // ---- floating bubble + panel ----
    private fun lp(w: Int, hh: Int, extra: Int = 0) = WindowManager.LayoutParams(w, hh,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or extra,
        PixelFormat.TRANSLUCENT)

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply { text = "FL"; setTextColor(-1); setBackgroundColor(0xAA000000.toInt()); setPadding(28, 18, 28, 18) }
        val p = lp(-2, -2).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }
        var dx = 0f; var dy = 0f; var moved = false
        b.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { dx = ev.rawX - p.x; dy = ev.rawY - p.y; moved = false }
                MotionEvent.ACTION_MOVE -> { p.x = (ev.rawX - dx).toInt(); p.y = (ev.rawY - dy).toInt(); moved = true; wm.updateViewLayout(b, p) }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(b, p); bubble = b
    }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(-1); setPadding(24, 24, 24, 24) }
        fun b(t: String, f: () -> Unit) { l.addView(Button(this).apply { text = t; setOnClickListener { f() } }) }
        b("Key") { capture("key") }
        b("Multiply (auto-repeat)") { capture("turbo") }
        b("Swipe") { capture("swipe") }
        b("Order (tap sequence)") { capture("order") }
        b("Delete all") { cur?.let { maps[it]?.clear() }; save(); closePanel(); toast("Deleted") }
        b("Click feedback: " + (if (feedback) "ON" else "OFF")) { feedback = !feedback; closePanel() }
        b("Close") { closePanel() }
        val p = lp(-2, -2).apply { gravity = Gravity.CENTER }
        wm.addView(l, p); panel = l
    }

    private fun closePanel() { panel?.let { wm.removeView(it) }; panel = null }
    private fun hideAll() { closePanel(); bubble?.let { wm.removeView(it) }; bubble = null }

    // ---- capture: touch screen points, then press a key to bind ----
    private fun capture(kind: String) {
        closePanel(); buf = ArrayList(); bindReady = false
        var sx = 0f; var sy = 0f; var t0 = 0L
        val v = object : View(this) {
            override fun onTouchEvent(ev: MotionEvent): Boolean {
                if (ev.action == MotionEvent.ACTION_DOWN) { sx = ev.rawX; sy = ev.rawY; t0 = ev.eventTime }
                if (ev.action == MotionEvent.ACTION_UP) {
                    val a = sx.toInt().toString() + " " + sy.toInt()
                    if (kind == "key") buf.add("click $a")
                    else if (kind == "turbo") buf.add("turbo $a")
                    else if (kind == "swipe") buf.add("slide $a ${ev.rawX.toInt()} ${ev.rawY.toInt()} ${maxOf(100L, ev.eventTime - t0)}")
                    else { if (buf.isNotEmpty()) buf.add("wait 80"); buf.add("click $a") }
                    bindReady = true
                    if (kind == "order") toast("Point added. Tap more, then press a key to finish")
                    else { wm.removeView(this); cap = null; toast("Now press a keyboard/gamepad button") }
                }
                return true
            }
        }
        v.setBackgroundColor(0x66000000)
        wm.addView(v, lp(-1, -1)); cap = v
        toast(if (kind == "swipe") "Drag from start to end point" else "Touch the screen point")
    }

    fun macro(text: String) {
        if (cur == null) { toast("Open your game first, then bind"); return }
        buf = ArrayList(text.lines().map { it.trim().replace("multiclick", "turbo") }.filter { it.isNotEmpty() && !it.startsWith("#") })
        bindReady = true; toast("Press a key to bind the macro")
    }

    // ---- storage ----
    private fun prefs() = getSharedPreferences("maps", MODE_PRIVATE)
    private fun save() {
        val c = cur ?: return
        prefs().edit().putString(c, (maps[c] ?: HashMap<Int, String>()).entries.joinToString("\n") { it.key.toString() + "|" + it.value }).apply()
    }
    private fun load(c: String) {
        val m = HashMap<Int, String>()
        prefs().getString(c, "")!!.split("\n").filter { it.contains("|") }.forEach {
            val i = it.indexOf("|"); m[it.substring(0, i).toInt()] = it.substring(i + 1)
        }
        maps[c] = m
    }
    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
}
